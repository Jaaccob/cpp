#include <iostream>

using namespace std;

int main(){
	auto a = 5;
	auto b = 11.5;
	cout << "a:" << a << endl;
	cout << "typ:" << sizeof(a) <<endl;
	cout << "b:"  << b << endl;
	cout << "typ:" << sizeof(b) << endl;
	return 1;
}
